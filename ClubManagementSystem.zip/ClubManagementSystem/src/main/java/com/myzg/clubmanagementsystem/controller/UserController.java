package com.myzg.clubmanagementsystem.controller;


import com.myzg.clubmanagementsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.myzg.clubmanagementsystem.pojo.Result;

import java.util.HashMap;

@RestController
public class UserController {
   @Autowired
    UserService userService;
    @PostMapping("/login")
    public Result Login(Integer userId, String password) {
        HashMap<String,Object> map=new HashMap<String,Object>();
        map.put("userId",userId);
        map.put("password",password);
        return userService.login(map);
    }
}
