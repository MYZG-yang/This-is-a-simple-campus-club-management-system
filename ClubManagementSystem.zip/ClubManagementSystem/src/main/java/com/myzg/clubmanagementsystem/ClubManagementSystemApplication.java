package com.myzg.clubmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ClubManagementSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClubManagementSystemApplication.class);
    }
}
