document.addEventListener("DOMContentLoaded",()=>{
    let index=0;
    const images=document.querySelectorAll(".impIndex");
    console.log(images[1])
    const interval=3000;
    function changeImage(){
        images[index].style.display="none";
        index=(index+1)%images.length;
        images[index].style.display="block";
    }
    setInterval(changeImage,interval);
})