$(function (){
    $('#login').click(function (){
        $.ajax({
            url:'/login',
            type:"POST",
            dataType:"json",
            data:{userId:$("#userId").val(),password:$("#password").val()},
            success:function (data){
                if(data.flag=="success"){
                    window.location.href="userIndex.html";
                }
            },
            error:function (){
                console.log("error")
            }
        })
    })
})