package com.myzg.clubmanagementsystem.service;

import com.myzg.clubmanagementsystem.pojo.Result;

import java.util.HashMap;

public interface UserService {
    Result login(HashMap<String,Object> map);
    Result userQ();
}
