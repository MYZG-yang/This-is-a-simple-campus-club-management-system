package com.myzg.clubmanagementsystem.service;

import com.myzg.clubmanagementsystem.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.myzg.clubmanagementsystem.pojo.Result;

import java.util.HashMap;
import java.util.List;

@Service
public class UserServerImpl implements UserService {

    @Autowired
    UserDao userDao;
    @Override
    public Result login(HashMap<String,Object> map) {
        Result result = new Result("fail", null);
        HashMap<String,Object> user = userDao.login(map);
        if (user!= null&& !user.isEmpty()) {
            result.setFlag("success");
            result.setData(user);
        }
        return result;
    }
    public Result userQ(){
        Result result=new Result("success",null);
        List<HashMap<String,Object>> list=userDao.userQ();
        result.setData(list);
        return result;
    }
}
