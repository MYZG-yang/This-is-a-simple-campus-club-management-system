package com.myzg.clubmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubManagementSystemApplicationTests {
    @Test
    void contextLoads() {
    }

}
