$(function (){
    $.ajax({
        url:"/Club",
        type:"POST",
        dataType:"json",
        success:function (data){
            $.each(data.data,function (index,item){
                $("#clubTable tbody").append(
                    $("<tr>").append(
                        $("<td>").text(item.ClubId),
                        $("<td>").text(item.ClubName),
                        $("<td>").text(item.ClubType),
                        $("<td>").text(item.Originator),
                        $("<td>").text(item.EstablishmentDate),
                        $("<td>").text(item.Introduction),
                        $("<td>").text(item.State),
                    )
                )
            })
        }
    })
})