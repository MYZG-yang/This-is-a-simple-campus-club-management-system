package com.myzg.clubmanagementsystem.service;

import com.myzg.clubmanagementsystem.pojo.Result;

import java.util.HashMap;

public interface ClubService {
    Result clubQ();
}
