package com.myzg.clubmanagementsystem.service;

import com.myzg.clubmanagementsystem.dao.ClubDao;
import com.myzg.clubmanagementsystem.pojo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
@Service

public class ClubServiceImpl implements ClubService{
    @Autowired
    ClubDao clubDao;
    public Result clubQ(){
        Result result=new Result("success",null);
        result.setData(clubDao.clubQ());
        return result;
    }
}
