package com.myzg.clubmanagementsystem.controller;

import com.myzg.clubmanagementsystem.pojo.Result;
import com.myzg.clubmanagementsystem.service.ClubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClubController {
    @Autowired
    ClubService clubService;
    @PostMapping("/Club")
    public Result clubQ(){
        return clubService.clubQ();
    }
}
